package com.example.campusos_;
public class MainActivity extends BaseActivity {@Override protected void onCreate(android.os.Bundle b){super.onCreate(b);if(Session.token().isEmpty())login();else dashboard();}}
