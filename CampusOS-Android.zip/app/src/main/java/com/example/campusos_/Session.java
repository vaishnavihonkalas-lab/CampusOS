package com.example.campusos_;
import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
public final class Session {
 private static SharedPreferences prefs; private static String token="";
 static void init(Context c){prefs=c.getSharedPreferences("campus_session",Context.MODE_PRIVATE);try{String data=prefs.getString("token","");if(!data.isEmpty()){Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(prefs.getString("iv",""),Base64.NO_WRAP)));token=new String(cipher.doFinal(Base64.decode(data,Base64.NO_WRAP)),java.nio.charset.StandardCharsets.UTF_8);}}catch(Exception e){clear();}}
 private static SecretKey key() throws Exception {KeyStore store=KeyStore.getInstance("AndroidKeyStore");store.load(null);if(!store.containsAlias("campus_token")){KeyGenerator generator=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");generator.init(new KeyGenParameterSpec.Builder("campus_token",KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());generator.generateKey();}return (SecretKey)store.getKey("campus_token",null);}
 static void save(String value,String role,int id) throws Exception {Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,key());String encrypted=Base64.encodeToString(cipher.doFinal(value.getBytes(java.nio.charset.StandardCharsets.UTF_8)),Base64.NO_WRAP);prefs.edit().putString("token",encrypted).putString("iv",Base64.encodeToString(cipher.getIV(),Base64.NO_WRAP)).putString("role",role).putInt("user_id",id).apply();token=value;}
 public static String token(){return token;} public static boolean admin(){return "admin".equals(prefs.getString("role",""));}public static int userId(){return prefs.getInt("user_id",0);}public static void clear(){token="";if(prefs!=null)prefs.edit().remove("token").remove("iv").remove("role").remove("user_id").apply();}
 static String endpoint(){return prefs.getString("endpoint",BuildConfig.API_BASE_URL);}static void endpoint(String value){prefs.edit().putString("endpoint",value).apply();clear();RetrofitClient.init();}
}
