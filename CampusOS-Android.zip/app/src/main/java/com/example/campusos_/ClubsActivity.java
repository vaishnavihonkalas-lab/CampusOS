package com.example.campusos_;
public class ClubsActivity extends FeatureActivity {@Override protected String section(){return "clubs";}}
