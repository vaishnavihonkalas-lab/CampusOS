package com.example.campusos_;
public class NoticesActivity extends FeatureActivity {@Override protected String section(){return "announcements";}}
