package com.example.campusos_;
import android.content.Intent;
import android.os.Bundle;
import android.graphics.Color;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.gson.*;
import retrofit2.*;
import java.util.*;
public class BaseActivity extends AppCompatActivity {
 protected LinearLayout body;protected ApiService api;private final List<Call<?>> pending=new ArrayList<>();
 interface Done {void accept(JsonElement json);}
 @Override protected void onCreate(Bundle saved){super.onCreate(saved);api=RetrofitClient.getApiService();}
 protected void screen(String title){ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(28,30,28,40);body.setBackgroundColor(Color.rgb(245,247,251));scroll.addView(body);setContentView(scroll);TextView heading=label(title);heading.setTextSize(27);heading.setTextColor(Color.rgb(23,43,77));}
 protected TextView label(String s){TextView t=new TextView(this);t.setText(s);t.setTextSize(16);t.setPadding(0,12,0,12);body.addView(t);return t;}
 protected EditText input(String hint,boolean password){EditText t=new EditText(this);t.setHint(hint);t.setSingleLine(true);if(password)t.setInputType(129);body.addView(t);return t;}
 protected void button(String title,Runnable action){Button b=new Button(this);b.setText(title);body.addView(b);b.setOnClickListener(v->action.run());}
 protected void divider(){TextView line=label("────────────────────");line.setTextColor(Color.LTGRAY);}
 protected void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
 protected void open(Class<?> c){startActivity(new Intent(this,c));}
 protected void feature(String section){startActivity(new Intent(this,FeatureActivity.class).putExtra("section",section));}
 protected boolean requireLogin(){if(Session.token().isEmpty()){login();return false;}return true;}
 protected void login(){Session.clear();startActivity(new Intent(this,LoginActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK));finish();}
 protected void dashboard(){Class<?> c=Session.admin()?AdminDashboardActivity.class:StudentDashboardActivity.class;startActivity(new Intent(this,c).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK));finish();}
 protected Map<String,Object> data(Object... pairs){Map<String,Object> m=new HashMap<>();for(int i=0;i<pairs.length;i+=2)m.put((String)pairs[i],pairs[i+1]);return m;}
 protected String s(JsonObject o,String key){return o.has(key)&&!o.get(key).isJsonNull()?o.get(key).getAsString():"";}
 protected int n(JsonObject o,String key){try{return o.get(key).getAsInt();}catch(Exception e){return 0;}}
 protected void send(Call<JsonElement> call,Done done){pending.add(call);call.enqueue(new Callback<JsonElement>(){public void onResponse(Call<JsonElement> c,Response<JsonElement> r){pending.remove(c);if(isFinishing()||isDestroyed())return;if(r.isSuccessful()&&r.body()!=null){done.accept(r.body());return;}String message="Request failed ("+r.code()+")";try{message=JsonParser.parseString(r.errorBody().string()).getAsJsonObject().get("error").getAsString();}catch(Exception ignored){}if(r.code()==401&&!(BaseActivity.this instanceof LoginActivity)){toast("Session expired. Please log in.");login();}else toast(message);}public void onFailure(Call<JsonElement> c,Throwable e){pending.remove(c);if(!c.isCanceled()&&!isFinishing())toast("Could not reach CampusOS. Check your connection and server address.");}});}
 protected void success(JsonElement json){toast(s(json.getAsJsonObject(),"message"));}
 protected void logout(){send(api.post("api/auth/logout",data()),json->login());}
 @Override protected void onDestroy(){for(Call<?> c:new ArrayList<>(pending))c.cancel();pending.clear();super.onDestroy();}
}
