package com.example.campusos_;
public class ProfileActivity extends FeatureActivity {@Override protected String section(){return "profile";}}
