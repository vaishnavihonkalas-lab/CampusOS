package com.example.campusos_;
public class EventsActivity extends FeatureActivity {@Override protected String section(){return "events";}}
