package com.example.campusos_;

public class Event {

    private String Event_ID;
    private String Event_Name;
    private String Date;
    private int registration_fee;
    private String Status;
    private String Club_Name;
    private String Venue_Name;

    public String getEvent_ID() {
        return Event_ID;
    }

    public String getEvent_Name() {
        return Event_Name;
    }

    public String getDate() {
        return Date;
    }

    public int getRegistration_fee() {
        return registration_fee;
    }

    public String getStatus() {
        return Status;
    }

    public String getClub_Name() {
        return Club_Name;
    }

    public String getVenue_Name() {
        return Venue_Name;
    }
}