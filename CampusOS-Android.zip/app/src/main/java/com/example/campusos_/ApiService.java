package com.example.campusos_;
import com.google.gson.JsonElement;
import java.util.Map;
import retrofit2.Call;
import retrofit2.http.*;
public interface ApiService {
 @GET Call<JsonElement> get(@Url String path);
 @POST Call<JsonElement> post(@Url String path,@Body Map<String,Object> data);
 @PUT Call<JsonElement> put(@Url String path,@Body Map<String,Object> data);
 @DELETE Call<JsonElement> delete(@Url String path);
}
