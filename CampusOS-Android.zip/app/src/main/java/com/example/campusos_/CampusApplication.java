package com.example.campusos_;
public class CampusApplication extends android.app.Application {
 @Override public void onCreate(){super.onCreate();Session.init(this);RetrofitClient.init();}
}
