package com.example.campusos_;
import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
public final class RetrofitClient {
 private static ApiService service;
 static void init(){OkHttpClient http=new OkHttpClient.Builder().connectTimeout(20,java.util.concurrent.TimeUnit.SECONDS).readTimeout(30,java.util.concurrent.TimeUnit.SECONDS).addInterceptor(chain->{okhttp3.Request.Builder request=chain.request().newBuilder();if(!Session.token().isEmpty())request.header("Authorization","Bearer "+Session.token());return chain.proceed(request.build());}).build();service=new Retrofit.Builder().baseUrl(Session.endpoint()).client(http).addConverterFactory(GsonConverterFactory.create()).build().create(ApiService.class);}
 public static ApiService getApiService(){return service;}
}
